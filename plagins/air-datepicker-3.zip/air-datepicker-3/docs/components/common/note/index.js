import Note from './note';
export default Note;

