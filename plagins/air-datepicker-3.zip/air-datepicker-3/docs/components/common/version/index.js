import Version from './version';
export default Version;

