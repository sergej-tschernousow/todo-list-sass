import Language from './language';
export default Language;

