import NavBar from './navBar';
export default NavBar;

