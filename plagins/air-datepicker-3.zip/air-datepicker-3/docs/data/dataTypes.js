export default {
    date: 'Date | string | number',
    views: '"days" | "months" | "years"'
}
